public class Ayi extends Canavar{
    public Ayi() {
        super("Ayı", 7, 20, 12);
    }
}
