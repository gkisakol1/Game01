public class Magara extends SavasLoc{

    Magara(Player player) {
        super(player, "Mağara", new Zombi(), "Yemek");
    }
}
