public class Nehir extends SavasLoc{

    Nehir(Player player) {
        super(player, "Nehir", new Ayi(), "Su");
    }
}
