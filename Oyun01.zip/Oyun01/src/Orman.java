public class Orman extends SavasLoc{
    Orman(Player player) {
        super(player, "Orman", new Vampir(), "Odun");
    }
}
