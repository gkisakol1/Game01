public class Vampir extends Canavar{
    public Vampir() {
        super("Vampir", 4, 14, 7);
    }
}
