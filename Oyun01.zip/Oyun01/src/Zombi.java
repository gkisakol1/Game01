public class Zombi extends Canavar{
    public Zombi() {
        super("Zombi", 3, 10, 4);
    }
}
